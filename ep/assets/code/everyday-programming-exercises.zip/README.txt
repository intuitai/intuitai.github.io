Everyday Programming -- Find the Bug exercises
Dr. Nobel Khandaker

445 exercises and 445 worked solutions, extracted from the book.

  exercises/ex_<chapter>_<group>_<n>.py   the program with the bug in it
  solutions/sol_<chapter>_<group>_<n>.py  the diagnosis and the corrected program

Almost every program runs on a stock CPython 3 with nothing installed:

  python3 exercises/ex_5_1_1.py

Two sets need more. Chapter 17 (testing) uses pytest. Section 13.2 imports
modules such as `conversions` and `shapes` that you are meant to have written
yourself -- those exercises are about the import mechanism, so they raise
ModuleNotFoundError until you create the module beside them.

Some exercises are meant to fail -- a syntax error or an exception is the
bug you are looking for. Read the docstring at the top of each file for what
the program was supposed to do.

Online, with links between each exercise and its solution:
https://intuitai.org/ep/
